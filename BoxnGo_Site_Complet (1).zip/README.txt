
Ce site Web statique est destiné à Box’n’Go.

Fonctionnalités :
- Formulaire de commande pour les étudiants
- Bouton de paiement Stripe (test public key)
- Design simple et responsive

Note : Pour un usage réel, remplacer le lien Stripe de test par un lien actif avec votre propre compte Stripe.
